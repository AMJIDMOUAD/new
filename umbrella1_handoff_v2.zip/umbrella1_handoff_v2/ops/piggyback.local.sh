#!/usr/bin/env bash
set -euo pipefail
: "${DAD_BASE_URL:=https://dad.remimediaventures.com}"
echo "== Upsert handshakes =="
for f in ops/handshakes/*.json; do
  echo " • $f"; curl -fsS -X POST "$DAD_BASE_URL/api/handshakes/upsert"     -H 'content-type: application/json' --data-binary @"$f" >/dev/null
done
echo "== Upsert routes =="
for f in ops/routes/*.jsonl; do
  echo " • $f"
  while read -r line; do
    [ -n "$line" ] && curl -fsS -X POST "$DAD_BASE_URL/api/leapq/routes"       -H 'content-type: application/json' --data-binary "$line" >/dev/null
  done < "$f"
done
echo "== Done =="
