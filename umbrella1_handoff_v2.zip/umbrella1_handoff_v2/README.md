# Umbrella-1 Handoff (Scaffold)

This is a minimal, working scaffold so packaging doesn't block you.
Replace each `apps/*` stub with your real code. Handshakes and routes are
small but valid JSON that piggyback cleanly.

## Quick Use
1. Unpack this archive.
2. Fill `.env` based on `.env.example`.
3. Upsert handshakes and routes:
   ```bash
   make piggyback || bash ops/piggyback.local.sh
   ```
4. Replace stubs with real app bundles over time.
